-- Mason Settings
require('mason').setup({
    ui = {
        icons = {
            package_installed = "✓",
            package_pending = "➜",
            package_uninstalled = "✗"
        }
    },
})

-- Mason-lspconfig Settings  (LS)
require('mason-lspconfig').setup({
    ensure_installed = { 'pyright', 'lua_ls', 'rust_analyzer', 'clangd',
'verible', 'matlab_ls'},
})

-- Mason-null-ls Settings (Formatters)
require("mason-null-ls").setup({
    ensure_installed = { "prettier", "clang-format", "stylua" },
    automatic_installation = true,
})

-- Mason-nvim-dap Settings (Debugers)
require("mason-nvim-dap").setup({
    ensure_installed = { "python", "cppdbg", "bash" },
    automatic_setup = true,  -- 自动配置 DAP 适配器
})

-- LspConfig Settings
local lspconfig = require('lspconfig')

local opts = { noremap = true, silent = true }
vim.keymap.set('n', '<space>e', vim.diagnostic.open_float, opts)
vim.keymap.set('n', '[d', vim.diagnostic.goto_prev, opts)
vim.keymap.set('n', ']d', vim.diagnostic.goto_next, opts)
vim.keymap.set('n', '<space>q', vim.diagnostic.setloclist, opts)

local on_attach = function(client, bufnr)
    -- Enable completion triggered by <c-x><c-o>, CMP
    vim.api.nvim_buf_set_option(bufnr, 'omnifunc', 'v:lua.vim.lsp.omnifunc')

    require "lsp_signature".on_attach({
    bind = true,           -- 这是必要的，确保输入模式下生效
    hint_enable = true,     -- 启用虚拟提示
    floating_window = true, -- 使用浮动窗口显示签名
    fix_pos = false,
    hint_prefix = "🔍 ",
    hi_parameter = "LspSignatureActiveParameter", -- 高亮当前参数
    handler_opts = {
    border = "rounded"
    },
  }, bufnr)

    -- See `:help vim.lsp.*` for documentation on any of the below functions
    local bufopts = { noremap = true, silent = true, buffer = bufnr }
    vim.keymap.set('n', 'gD', vim.lsp.buf.declaration, bufopts)
    vim.keymap.set('n', 'gd', vim.lsp.buf.definition, bufopts)
    vim.keymap.set('n', '<C-h>', vim.lsp.buf.hover, bufopts)
    vim.keymap.set('n', 'gi', vim.lsp.buf.implementation, bufopts)
    vim.keymap.set('n', '<space>wa', vim.lsp.buf.add_workspace_folder, bufopts)
    vim.keymap.set('n', '<space>wr', vim.lsp.buf.remove_workspace_folder, bufopts)
    vim.keymap.set('n', '<space>wl', function()
        print(vim.inspect(vim.lsp.buf.list_workspace_folders()))
    end, bufopts)

    vim.keymap.set('n', '<space>D', vim.lsp.buf.type_definition, bufopts)
    vim.keymap.set('n', '<space>ca', vim.lsp.buf.code_action, bufopts)
    vim.keymap.set('n', 'gr', vim.lsp.buf.references, bufopts)
    vim.keymap.set("n", "<space>f", function()
        vim.lsp.buf.format({ async = true })
    end, bufopts)
end

-- Python Settings
lspconfig.pyright.setup({
	on_attach = on_attach,
    settings = {
      python = {
        analysis = {
          typeCheckingMode = "basic",
          autoSearchPaths = true,
          useLibraryCodeForTypes = true,
          diagnosticMode = "workspace",
          autoImportCompletions = false,
        },
        pythonPath = '/opt/homebrew/bin/python3.12'
      },
    },
})

local python_config = require('Languages.python')

python_config.setup_folding()        -- Folding 
python_config.setup_python_keymaps() -- Keymaps
python_config.debuger()              -- Debuger

-- C Settings
lspconfig.clangd.setup{
    on_attach = on_attach,
    settings = {
        checkUpdates = true,
    },
    flags = {
        debounce_text_changes = 150,
    }
}

-- Lua settings
lspconfig.lua_ls.setup{
    on_attach = on_attach,
}

-- Verilog Settings
local lsp_flags = {
  debounce_text_changes = 150,
}

lspconfig.verible.setup {
    on_attach = on_attach,
    flags = lsp_flags,
    root_dir = function() return vim.uv.cwd() end
}

-- Matlab Settings
lspconfig.matlab_ls.setup{
    on_attach = on_attach,
}
