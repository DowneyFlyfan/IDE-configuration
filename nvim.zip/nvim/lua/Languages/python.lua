local M = {}
local dap = require("dap")

function M.setup_folding()
  vim.api.nvim_exec([[
    autocmd FileType python setlocal foldmethod=indent
  ]], false)

  vim.cmd([[
    highlight Folded guibg=DarkYellow guifg=DarkBlue
  ]])

  vim.o.foldlevel = 0 -- 默认全部折叠
  vim.o.foldnestmax = 4 -- 允许最多嵌套 4 层折叠
  vim.o.foldminlines = 1 -- 折叠最小包含的行数
end

-- Python Keymap Settings
function M.setup_python_keymaps()
    vim.api.nvim_set_keymap('n', '<C-e>', ':w<CR>:!python3.12 %<CR>', { noremap = true, silent = true })
    vim.api.nvim_set_keymap('n', 'ct', ":lua require'dap'.continue()<CR>", { noremap = true, silent = true })
    vim.api.nvim_set_keymap('n', 'si', ":lua require'dap'.step_into()<CR>", { noremap = true, silent = true })
    vim.api.nvim_set_keymap('n', 'so', ":lua require'dap'.step_over()<CR>", { noremap = true, silent = true })
    vim.api.nvim_set_keymap('n', 'ro', ":lua require'dap'.repl.open()<CR>", { noremap = true, silent = true })
    vim.api.nvim_set_keymap('n', 'sb', ":lua require'dap'.toggle_breakpoint()<CR>", { noremap = true, silent = true })
end

-- Python Debuger Settings
function M.debuger()
dap.adapters.python = {
    type = "executable",
    command = "/usr/bin/python3",
    args = { "-m", "debugpy.adapter" },
}

dap.configurations.python = {
    {
        type = "python",
        request = "launch",
        name = "Launch file",
        program = "${file}",
        pythonPath = "/usr/bin/python3",
    },
}
end

return M
