local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
if not (vim.uv or vim.loop).fs_stat(lazypath) then
  vim.fn.system({
    "git",
    "clone",
    "--filter=blob:none",
    "https://github.com/folke/lazy.nvim.git",
    "--branch=stable", -- latest stable release
    lazypath,
  })
end

vim.opt.rtp:prepend(lazypath)

require("lazy").setup({

	-- Vscode-like pictograms
	{
		"onsails/lspkind.nvim",
		event = { "VimEnter" },
	},
	-- Auto-completion engine
	{
		"hrsh7th/nvim-cmp",
		dependencies = {
			"lspkind.nvim",
			"hrsh7th/cmp-nvim-lsp", -- lsp auto-completion
			"hrsh7th/cmp-buffer", -- buffer auto-completion
			"hrsh7th/cmp-path", -- path auto-completion
			"hrsh7th/cmp-cmdline", -- cmdline auto-completion
		},
		config = function()
			require("config.nvim-cmp")
		end,
	},
	-- Code snippet engine
	{
		"L3MON4D3/LuaSnip",
		version = "v2.*",
        config = function ()
            require('Snippets.snippets')
        end
	},

---- LSP manager

    -- LSP Tools
    {
	"williamboman/mason.nvim", -- All Language Tools Management UI
	"williamboman/mason-lspconfig.nvim", -- LSP Management Tool
	"neovim/nvim-lspconfig", -- LSP Settings tool
    },

    -- Debug Tools
    {
    "jay-babu/mason-nvim-dap.nvim",
    dependencies = { "mfussenegger/nvim-dap"},
    },

    -- Formatting Tools
    {
    'jayp0521/mason-null-ls.nvim',
    dependencies = { 'jose-elias-alvarez/null-ls.nvim'},
    ft = {"python", "c", "cpp", "lua"},
    },

    -- nvim-treesitter
    {
    "nvim-treesitter/nvim-treesitter",
    config = function()
        require("config.treesitter")
    end
    },

    -- undotree
    {
    "mbbill/undotree",
    config = function()
        vim.keymap.set('n', 'UD', vim.cmd.UndotreeToggle)
    end,
    },

    -- nvim-tree
    {
    "nvim-tree/nvim-tree.lua",
    config = function()
        require('config.nvimtree')
    end,
    -- enabled = false, -- Disable it
    },

    -- Web Devicons
    {
        "nvim-tree/nvim-web-devicons",
    },

    -- LSP Signature
    {
    "ray-x/lsp_signature.nvim",
    event = "InsertEnter",
    },

    -- lualine
    {
    'nvim-lualine/lualine.nvim',
    dependencies = { 'nvim-tree/nvim-web-devicons' },
    config = function()
        require('config.lualine')
    end
    },

    -- Multi-Cursor
    {
    "terryma/vim-multiple-cursors",
    },

    -- Parenthesis Completion
    {
    'windwp/nvim-autopairs',
    event = "InsertEnter",
    config = true,
    },

    -- Markdown
    {
    "iamcco/markdown-preview.nvim",
    cmd = { "MarkdownPreviewToggle", "MarkdownPreview", "MarkdownPreviewStop" },
    build = "cd app && yarn install",
    init = function()
      vim.g.mkdp_filetypes = { "markdown" }
    end,
    ft = { "markdown" },
    config = function()
        require('config.markdown-preview')
    end
    },

    -- fzf-lua
    {
    "ibhagwan/fzf-lua",
    -- optional for icon support
    dependencies = { "nvim-tree/nvim-web-devicons" },
    config = function()
        require('config.fzf-lua')
    end
    },

    -- gitsigns
    {
        "lewis6991/gitsigns.nvim",
        config = function ()
            require('config.gitsigns')
        end
    }
})
