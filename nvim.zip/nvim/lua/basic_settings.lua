-- Hint: use `:h <option>` to figure out the meaning if needed
vim.opt.clipboard = 'unnamedplus' -- use system clipboard
vim.opt.completeopt = { 'menu', 'menuone', 'noselect' }
vim.opt.mouse = 'a' -- allow the mouse to be used in Nvim
vim.o.scrolloff = 5
vim.bo.modifiable = true
vim.g.python3_host_prog = '/opt/homebrew/bin/python3.11'

-- Tab
vim.opt.tabstop = 4 -- number of visual spaces per TAB
vim.opt.softtabstop = 4 -- number of spacesin tab when editing
vim.opt.shiftwidth = 4 -- insert 4 spaces on a tab
vim.opt.expandtab = true -- tabs are spaces, mainly because of python

vim.api.nvim_set_keymap('n', '<Space>1', ':tabn 1<CR>', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', '<Space>2', ':tabn 2<CR>', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', '<Space>3', ':tabn 3<CR>', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', '<Space>4', ':tabn 4<CR>', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', '<Space>5', ':tabn 5<CR>', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', '<Space>6', ':tabn 6<CR>', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', '<Space>7', ':tabn 7<CR>', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', '<Space>8', ':tabn 8<CR>', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', '<Space>9', ':tabn 9<CR>', { noremap = true, silent = true })

-- UI config
vim.opt.number = true -- show absolute number
vim.opt.relativenumber = true -- add numbers to each line on the left side
vim.opt.cursorline = true -- highlight cursor line underneath the cursor horizontally
vim.api.nvim_set_hl(0, 'CursorLine', { bg = '#3e3e3e' })  -- 设置光标行的背景颜色
vim.opt.splitbelow = true -- open new vertical split bottom
vim.opt.splitright = true -- open new horizontal splits right

-- Searching
vim.opt.incsearch = true -- search as characters are entered
vim.opt.hlsearch = true -- do not highlight matches
vim.opt.ignorecase = true -- ignore case in searches by default
vim.opt.smartcase = true -- but make it case sensitive if an uppercase is entered
vim.api.nvim_set_keymap('n', '<Space>]', ':nohlsearch<CR>', { noremap = true, silent = true })

-- Windows Movement
vim.api.nvim_set_keymap('n', '<Down>', ':resize +1<CR>', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', '<Up>', ':resize -1<CR>', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', '<Right>', ':vertical resize -3<CR>', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', '<Left>', ':vertical resize +3<CR>', { noremap = true, silent = true })

-- Cursor Movement
vim.api.nvim_set_keymap('n', 'H', '^', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', 'H', '^', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', 'J', '5j', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', 'K', '5k', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', 'L', '$', { noremap = true, silent = true })

vim.api.nvim_set_keymap('v', 'J', '5j', { noremap = true, silent = true })
vim.api.nvim_set_keymap('v', 'K', '5k', { noremap = true, silent = true })

-- Windows Switch
vim.api.nvim_set_keymap('n', '<Space>h', '<C-w>h', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', '<Space>j', '<C-w>j', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', '<Space>k', '<C-w>k', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', '<Space>l', '<C-w>l', { noremap = true, silent = true })

-- Theme
vim.cmd('colorscheme desert')

-- Transparent Background
vim.cmd([[
    highlight Normal guibg=NONE ctermbg=NONE
    highlight NonText guibg=NONE ctermbg=NONE
]])
