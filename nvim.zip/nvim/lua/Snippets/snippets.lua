local ls = require("luasnip")

vim.keymap.set({"i"}, "<C-K>", function() ls.expand() end, {silent = true})
vim.keymap.set({"i", "s"}, "<C-L>", function() ls.jump( 1) end, {silent = true})
vim.keymap.set({"i", "s"}, "<C-J>", function() ls.jump(-1) end, {silent = true})

vim.keymap.set({"i", "s"}, "<C-E>", function()
	if ls.choice_active() then
		ls.change_choice(1)
	end
end, {silent = true})

-- Python Snippets
ls.add_snippets("python", {
    ls.snippet("def", {
        ls.text_node("def "),
        ls.insert_node(1, "function_name"),
        ls.text_node("("),
        ls.insert_node(2, "args"),
        ls.text_node("):"),
        ls.text_node("\n    "), -- 换行
        ls.insert_node(3, "pass"),
    }),
    ls.snippet("cm", {
        ls.text_node("# ---- "),
        ls.insert_node(1, "comment"),  -- 插入节点1，用户输入
        ls.text_node(" ----"),
    }),
})

-- Markdown Snippets
