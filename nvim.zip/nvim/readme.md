# Neovim Configuration

- This is a backup for my neovim configuration
