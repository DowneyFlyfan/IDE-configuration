-- Loading Configs
require('basic_settings')
require('Plugins')
require('lsp')
